# PEGA AQUÍ TODO EL CÓDIGO DE TU CLASE InstitutionalEngine CORREGIDA
# Incluye imports, configuración y la clase completa
